/*
    JTSK-320111
    a3_p1.c
    Aayush Sharma Acharya
    a.sharmaacharya@jacobs-university.de
*/
#include <stdio.h>

int main(){
    int i =8 ;
    while (i>=4){
        printf("i is %d\n", i);
        i--;
    }
    printf("That's it. \n");
    return 0;
}